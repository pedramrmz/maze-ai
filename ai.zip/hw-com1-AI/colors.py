# RGB colors
red = (255, 0, 0)
white = (255, 255, 255)
black = (0, 0, 0)
blue = (0, 0, 255)
evenColor = (63, 63, 63)
oddColor = (70, 70, 70)
blockColor = (28, 18, 18)
startColor = (58, 42, 10)
endColor = (0, 244, 11)
playerColor = (12, 100, 150)
selectionColor = (12, 232, 255)

