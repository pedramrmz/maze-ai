# parameter to creating the matrix
width, height = 4 * 130, 4 * 130
rows, cols = 13, 13
square_size = width // cols
